import os, json, re, math
from datetime import datetime
from zoneinfo import ZoneInfo
from flask import Flask, request, jsonify, send_from_directory
import requests

app = Flask(__name__, static_folder="public")

TSDB_BASE="https://www.thesportsdb.com/api/v1/json/123"

def tsdb(path, params):
    r=requests.get(TSDB_BASE+"/"+path, params=params, timeout=12)
    r.raise_for_status()
    return r.json()

def find_team(name):
    data=tsdb("searchteams.php", {"t":name})
    teams=data.get("teams") or []
    return teams[0] if teams else None

def upcoming_for_team(team_id):
    data=tsdb("eventsnext.php", {"id":team_id})
    return data.get("events") or []

def parse_dt(v):
    if not v: return None
    try:
        dt=datetime.fromisoformat(v.replace("Z","+00:00"))
        return dt
    except:
        return None

def choose_event(home_id, away_id, home_name, away_name):
    events=upcoming_for_team(home_id)
    candidates=[]
    for e in events:
        hid=str(e.get("idHomeTeam") or "")
        aid=str(e.get("idAwayTeam") or "")
        if (hid==str(home_id) and aid==str(away_id)) or (
            str(e.get("strHomeTeam","")).lower()==home_name.lower() and
            str(e.get("strAwayTeam","")).lower()==away_name.lower()):
            candidates.append(e)
    if not candidates:
        # fallback: next event containing both names
        for e in events:
            text=(e.get("strHomeTeam","")+" "+e.get("strAwayTeam","")).lower()
            if home_name.lower() in text and away_name.lower() in text:
                candidates.append(e)
    if not candidates: return None
    return candidates[0]

def safe_num(v):
    try: return float(v)
    except: return None

@app.get("/")
def index():
    return send_from_directory("public","index.html")

@app.post("/api/analyze")
def analyze():
    body=request.get_json(force=True)
    home=body.get("home","").strip()
    away=body.get("away","").strip()
    if not home or not away: return "Équipes manquantes",400

    ht=find_team(home); at=find_team(away)
    if not ht or not at:
        return jsonify({"error":"Équipe introuvable dans la source d'identification."}),404

    event=choose_event(ht.get("idTeam"),at.get("idTeam"),home,away)
    result={
      "match":{"home":home,"away":away},
      "sources":["TheSportsDB"],
      "prediction":{
        "winner":"Non déterminé",
        "score":"Non déterminé",
        "totalGoals":"Non déterminé",
        "confidence":0,
        "note":"Le moteur ne produit pas de fausse certitude : une source de prédiction/cotes spécialisée doit être connectée pour calculer le verdict."
      }
    }

    if event:
        dt=parse_dt(event.get("dateEvent")+"T"+(event.get("strTime") or "00:00:00"))
        if dt:
            try: ci=dt.astimezone(ZoneInfo("Africa/Abidjan")).strftime("%d/%m/%Y à %H:%M")
            except: ci=dt.isoformat()
        else: ci="Date à confirmer"
        result["match"].update({
            "dateCI":ci,
            "competition":event.get("strLeague") or "Compétition non renseignée",
            "venue":event.get("strVenue") or "Stade non renseigné",
            "city":event.get("strCity") or "Ville non renseignée",
            "eventId":event.get("idEvent")
        })
        result["sources"].append("Calendrier / événement")
    else:
        result["match"]["dateCI"]="Aucun affrontement futur confirmé par cette source"
    return jsonify(result)

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8080")))
